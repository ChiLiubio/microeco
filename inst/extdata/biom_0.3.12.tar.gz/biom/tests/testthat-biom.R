library("testthat")
test_package("biom")