library(testthat)
library(qiimer)

test_package("qiimer")
